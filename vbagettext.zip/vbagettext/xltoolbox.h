/*!
    \file xltoolbox.h The XL Toolbox DLL.
*/
/*

    xltoolbox.dll
    =============

    xltoolbox.cpp

    Part of the XLToolbox addin.
    http://xltoolbox.sourceforge.net

    (c) Copyright 2011-2012 Daniel Kraus
    License: GPL v2.

    $Id$


    Note: When building this DLL using Code::Blocks and the MinGW/GNU C++
    compiler, make sure to add "-Wl,--kill-at" to the links options (without
    quotes). Otherwise the function name will be exported undecorated, and
    the VBA addin won't be able to import the function.

    Sample VBA declaration:

        Private Declare Function simplergb2cmyk _
            Lib "xltoolbox.dll" _
            (ByVal hbitmap As Long, ByVal numpixels As Long) As Long

    Changes:
    0.2     Add compute_hash and ReverseByteOrderLong functions.

*/

#ifndef __MAIN_H__
#define __MAIN_H__

#include <windows.h>
#include <stdint.h>


/*  To use this exported function of dll, include this header
 *  in your project.
 */

#ifdef BUILD_DLL
    #define DLL_EXPORT __declspec(dllexport)
#else
    #define DLL_EXPORT __declspec(dllimport)
#endif


#ifdef __cplusplus
extern "C"
{
#endif

/// Obtain the version number of the DLL.
/*! Returns a pointer to an ANSI string containing the version number of the XL Toolbox DLL.
    In order to use this function in a VBA project, you need to determine the string length
    by calling lstrlenA() from kernel32.dll, then RtlMoveMemory() from kernel32.dll to copy
    the string to a Visual Basic byte array.
    \returns Pointer to an ANSI string.
*/
DLL_EXPORT const char * __stdcall xltbdll_version();


/// Basic RGB-to-CMYK color separation.
/*! Performs very basic RGB-to-CMYK color separation, using an estimation formula.
    Users should be notified that this is only a very rough estimation and should
    be used only if a CMYK image <i>must</i> be produced and color management is <i>not</i>
    available on the system.
    \param[in] hbitmap       Pointer to a bitmap where each pixel is represented by four bytes.
    \param[in] numpixels     The number of pixels to convert. If this exceeds the actual size of
                            the bitmap, a <b>segmentation fault</b> will invariably occur.
    \retval 0 success
    \retval 1 parameter error (no bitmap or zero pixels)
*/
DLL_EXPORT int __stdcall simplergb2cmyk(int hbitmap, const unsigned int numpixels);


/// Computes the p value of the standardized range.
/*! Computes the p value of the standardized range, as used for the Tukey test
    for multiple comparisons. This algorithm has been ported from the Fortran code
    from Applied Statistics, algorithm AS 190 - Appl. Statist. (1983) Vol.32, No. 2
    \param[in] q            The q statistic
    \param[in] df           The degrees of freedom ("error DF" or "within DF" of the ANOVA)
    \param[in] n            The number of means (i.e., the total number of means being tested)
    \param[in] lowertail    True, if the lower tail of the distribution is to be returned.
    \returns        The probability p if sucessful; or -1 if an error occurred.
*/
DLL_EXPORT double __stdcall ptukey(double *q, int *df, int *n, bool *lowertail);


/*! Computes the gettext hash value for a key (i.e., text string).

    The algorithm is taken directly from the hash.c source code of the GNU gettext
    library, under the GNU GPL v. 2.

    From: gettext-0.14.4-src.zip\src\gettext\0.14.4\gettext-0.14.4-src\gettext-tools\lib\
    File: hash.c

    \param *key     Pointer to a string buffer (use ByRef LongPtr from VBA)
    \param keylen   Length of the buffer (use ByVal as Long from VBA)
    \return         gettext hash value
*/
DLL_EXPORT unsigned long __stdcall compute_hashval (const void *key, size_t keylen);


/*! Reverses the byte order of a 32-bit long integer.

    Can be used to read binary files that were written in big-endian mode
    with little-endian Windows.
    \param  n   A 32-bit integer whose byte order is to be reversed.
    \return     The integer with reversed byte order.
*/
DLL_EXPORT int32_t __stdcall ReverseByteOrderLong (int32_t n);


#ifdef __cplusplus
}
#endif


/// CMYK pixel structure.
/*! A four-byte structure holding CMYK color data for a pixel. */
struct CMYK
{
    uint8_t c; ///< Cyan
    uint8_t m; ///< Magenta
    uint8_t y; ///< Yellow
    uint8_t k; ///< Black
};



#endif // __MAIN_H__
