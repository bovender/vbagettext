vbagettext demo
===============

This archive contains demo files for the vbagettext library.

For more information, see <http://vbagettext.sf.net>.

This code is distributed under the GNU GPL v2 license (cf. the accompanying
file vbagettextdemo-license.txt).

To try out the example, open the vbagettextdemo.xls file in Microsoft(R)
Excel(R). In newer versions of Excel(R), you may need to relax your security
settings a little bit, otherwise you will not be able to bring up the
demo UserForm by clicking on the ActiveX button that says "Start".
Alternatively, you can hit Alt+F11 to run the Visual Basic IDE and have a
look at the code, or start the demonstration by entering:

	Form_Demo.show

in the 'immediate' window.


Contact
-------

Please feel free to contact me, Daniel Kraus ('bovender'), if you have any
questions. Be advised however that I am only a hobby programmer with a
day-time job and a life.

<!--- vim: set tw=76 fo=tqn : -->
